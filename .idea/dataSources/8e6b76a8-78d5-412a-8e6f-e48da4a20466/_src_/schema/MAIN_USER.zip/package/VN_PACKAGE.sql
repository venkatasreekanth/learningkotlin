CREATE PACKAGE VN_PACKAGE AS 

  type qt_pb_rank_wksp is record (
    adrs_country_lov varchar2(2),
    part_class number,
    pb_rank number,
    region_id number,
    region_text varchar2(80),
    root_id number,
    vendor_id number,
    vn_quote_profile_detail vn_quote_profile_detail_rec%rowtype
  );
  
  type vn_quote_profile_detail_list is table of vn_quote_profile_detail_rec%rowtype;

  function vn_qt_prof_return_rating_ss(vendor_id_1 in number,
                                       part_class in number,
                                       root_id in number, 
                                       adrs_country_lov in varchar2,
                                       return_type in number) return number;

  procedure determine_rating(qt_pb_rank in out qt_pb_rank_wksp,
                             vqp_country_class_list in vn_quote_profile_detail_list, 
                             vqp_country_list in vn_quote_profile_detail_list,
                             vqp_region_class_list in vn_quote_profile_detail_list, 
                             vqp_region_list in vn_quote_profile_detail_list,
                             vqp_class_list in vn_quote_profile_detail_list, 
                             vqp_default_list in vn_quote_profile_detail_list);

  function is_region_match(vn_quote_profile_detail in vn_quote_profile_detail_rec%rowtype,
                           qt_pb_rank in qt_pb_rank_wksp) return number;

  procedure qt_calculate_pb_rank(qt_pb_rank in out qt_pb_rank_wksp);

  function get_vendor_id_map(vendor_id1 in number,
                             corporate_id1 in number) return varchar2;
 
END VN_PACKAGE;
/
