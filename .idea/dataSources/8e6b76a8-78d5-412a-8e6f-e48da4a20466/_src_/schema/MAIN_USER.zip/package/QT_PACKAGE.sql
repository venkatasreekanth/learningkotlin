CREATE PACKAGE           QT_PACKAGE AS

  type qt_detail_price_hist_wksp is record (
    date_effective_start timestamp,
    date_expiration timestamp,
    authorization_cost number,
    break_price number,
    vendor_special_cost number,
    break_quantity number,
    count_times_quoted number,
    detail_index number,
    detail_glue number,
    dkc_ship_debit_id number,
    quantity_quoted number,
    quote_id number,
    registration_number varchar2(20),
    nflag_no_better_pricing number,
    nflag_no_bid number,
    nflag_on_vendor_quote number,
    nflag_awarded_mpl_tier number,
    nflag_mpl_pricing_applied number,
    nflag_reg_to_another_disti number,
    location varchar2(42),
    root_id number,
    master_root_id number,
    master_part_id number
  );

  type qt_detail_price_hist_list is table of qt_detail_price_hist_wksp;

  type t_refcursor is ref cursor;

  procedure QT_DETAIL_PRICE_HIST_WKSP_DFLT(detail_price_hist in out qt_detail_price_hist_wksp,
                                           default_value number default 0);

  procedure get_spc_cost_info(special_cost_id1 in number,
                              temp_date in out number,
                              qt_detail_price_hist_wksp1 in out qt_detail_price_hist_wksp);

  procedure filter_price_hist_list(full_list in out qt_detail_price_hist_list,
                                   filtered_list in out qt_detail_price_hist_list);

  procedure add_pricing_to_list(qt_detail_df in qt_detail_rec%rowtype,
                                price_hist_list in out qt_detail_price_hist_list);

  procedure qt_detail_price_hist_ss(qt_detail_df in qt_detail_rec%rowtype,
                                    price_hist_list in out qt_detail_price_hist_list);

  function qt_detail_price_hist(root_id in number,
                                part_id in number,
                                non_inventory_part_number in qt_detail_rec.non_inventory_part_number%type,
                                quote_id in number,
                                detail_glue in number,
                                nflag_on_vendor_quote_1 in number,
                                nflag_on_vendor_quote_2 in number,
                                nflag_on_vendor_quote_3 in number,
                                nflag_on_vendor_quote_4 in number,
                                nflag_on_vendor_quote_5 in number,
                                nflag_on_vendor_quote_6 in number) return qt_detail_price_hist_list pipelined;

  function calc_avg_cost(root_id in number,
                         part_id in number,
                         non_inventory_part_number in qt_detail_rec.non_inventory_part_number%type,
                         quote_id in number,
                         detail_glue in number,
                         nflag_on_vendor_quote_1 in number,
                         nflag_on_vendor_quote_2 in number,
                         nflag_on_vendor_quote_3 in number,
                         nflag_on_vendor_quote_4 in number,
                         nflag_on_vendor_quote_5 in number,
                         nflag_on_vendor_quote_6 in number,
                         duty_multiplier in number,
                         transport_multiplier in number,
                         local_market_multiplier in number,
                         exchange_rate_multiplier in number,
                         foreign_resale_multiplier in number,
                         break_price in number,
                         break_quantity in number) return number;

END QT_PACKAGE;
/
