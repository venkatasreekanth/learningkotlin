CREATE PACKAGE           "SO_PACKAGE" AS

  type t_so_schedule_item_wksp is record (
    --detail_schedule_rec so_order_detail_schedule_rec%rowtype,
    -- The following are from so_order_detail_schedule_rec
    -- pipelined functions can't return records with embedded records
    date_cust_in_house date,
    date_deferred date,
    date_delivery date,
    date_initial_reservationX date, --was dup of below declaration
    date_release date,
    detail_glue number,
    quantity_allocated number,
    quantity_invoiced number,
    quantity_scheduled number,
    salesorder_id number,
    schedule_sequence number,
    edi_reference_id varchar2(30),
    -- end of so_order_detail_schedule_rec
    date_initial_reservation date,
    display_date date,
    extended_price number,
    current_rsvd_ship_qty number,
    current_rsvd_noship_qty number,
    current_backordered_qty number,
    current_deferred_qty number,
    display_index number
  );

  type t_schedule_list is table of t_so_schedule_item_wksp;

  type so_price_history_wksp is record (
      bonded_qty number,
      break_price number,
      break_quantity number,
      contract_id number,
      current_backordered_qty number,
      current_deferred_qty number,
      current_rsvd_ship_qty number,
      date_entered date,
      detail_glue number,
      detail_index number,
      dkc_ship_debit_id number,
      flag_scheduled_order char(1),
      initial_immediate_qty number,
      invoice_id number,
      location varchar2(42),
      margin number,
      nflag_awarded_mpl_tier number,
      nflag_mpl_pricing_applied number,
      nflag_no_better_pricing number,
      nflag_no_bid number,
      nflag_reg_to_another_disti number,
      quantity_shipped number,
      quote_detail_glue number,
      quote_id number,
      registration_number varchar2(20),
      root_id number,
      salesorder_id number,
      schedule_count number,
      shipped_to_date_qty number,
      master_root_id number,
      master_part_id number
  );

  type so_price_history_list is table of so_price_history_wksp;

  type t_refcursor is ref cursor;

  procedure so_price_history_ss(so_invoice_detail in so_invoice_detail_rec%rowtype,
                                price_hist_list in out so_price_history_list);

  procedure add_so_pricing_to_list(so_order_detail in so_order_detail_rec%rowtype,
                                   price_hist_list in out so_price_history_list);

  procedure add_si_pricing_to_list(so_invoice_detail in so_invoice_detail_rec%rowtype,
                                   price_hist_list in out so_price_history_list);

  procedure calc_so_margin(so_order_header in so_order_header_rec%rowtype,
                           so_order_detail so_order_detail_rec%rowtype,
                           margin in out number);

  procedure calc_si_margin(so_invoice_header in so_invoice_header_rec%rowtype,
                           so_invoice_detail so_invoice_detail_rec%rowtype,
                           margin in out number);

  function so_price_history(root_id in number,
                            part_id in number) return so_price_history_list pipelined;

  procedure SO_SCHEDULE_ITEM_WKSP_DEFAULT(sched_wksp in out t_so_schedule_item_wksp);
  procedure sched_rec_to_wksp(rec in out so_order_detail_schedule_rec%rowtype, wksp in out t_so_schedule_item_wksp);
  procedure sched_wksp_to_sched_list(wksp in t_so_schedule_item_wksp, sched_list in out t_schedule_list);

  function ApplyReservations(reservation_index in out number,
                             sched_wksp in out t_so_schedule_item_wksp,
                             rsv_wksp in out GS_PACKAGE.t_gs_reserve_item_wksp,
                             rsv_list in out GS_PACKAGE.t_reservation_list,
                             sched_list_sort in out t_schedule_list) return number;

  function so_order_det_rsv_list_fetch_ss(p_salesorder_id in number,
                                          p_detail_glue in number,
                                          p_reservation_list in out GS_PACKAGE.t_reservation_list) return number;

  function so_detail_list_alloc_ss(p_detail_glue in number,
                                   p_salesorder_id in number,
                                   p_current_deferred_qty in number,
                                   p_current_rsvd_ship_qty in number,
                                   p_current_rsvd_noship_qty in number,
                                   p_current_backordered_qty in number) return t_schedule_list pipelined;

  procedure so_schedule_list_alloc_ss(p_current_rsvd_ship_qty in number,
                                      p_current_rsvd_noship_qty in number,
                                      p_current_backordered_qty in number,
                                      p_current_deferred_qty in number,
                                      sched_list in out t_schedule_list);

  function so_schedule_list_read_ss(p_salesorder_id in number,
                                    p_detail_glue in number,
                                    p_current_rsvd_ship_qty in number,
                                    p_current_rsvd_noship_qty in number,
                                    p_current_backordered_qty in number,
                                    p_current_deferred_qty in number,
                                    p_mode in char,
                                    p_virtual_mode in char) return t_schedule_list pipelined;

END SO_PACKAGE;
/
