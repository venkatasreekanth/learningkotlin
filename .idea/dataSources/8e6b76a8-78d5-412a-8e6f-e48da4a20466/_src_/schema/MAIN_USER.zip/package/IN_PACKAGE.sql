CREATE PACKAGE           IN_PACKAGE AS 

  type t_in_compute_pricing_return is record (
    part_id                         number,
    country_currency_code           number,
    code_geo_region                 number,
    company_type                    number,
    target_date                     date,
    current_price_break_quantity_1  number,
    current_price_break_quantity_2  number,
    current_price_break_quantity_3  number,
    current_price_break_quantity_4  number,
    current_price_break_quantity_5  number,
    current_price_break_quantity_6  number,
    current_price_break_quantity_7  number,
    current_price_break_quantity_8  number,
    current_price_break_quantity_9  number,
    current_price_1                 number,
    current_price_2                 number,
    current_price_3                 number,
    current_price_4                 number,
    current_price_5                 number,
    current_price_6                 number,
    current_price_7                 number,
    current_price_8                 number,
    current_price_9                 number,
    duty_multiplier                 number,
    exchange_rate_multiplier        number,
    foreign_resale_multiplier       number,
    local_market_multiplier         number,
    transport_multiplier            number
  );

  type in_compute_pricing_return_tbl is table of t_in_compute_pricing_return;

  type gs_parts_available_wksp is record (
    part_header in_part_header_rec%rowtype,
    quantity_available number,
    code_compliant_type number
  );

  type gs_parts_available_list is table of gs_parts_available_wksp;

  type t_in_search_data_struc is record (
    --From IN_SEARCH_DATA_HEADER_WKSP and IN_COMBINED_QUANTITIES_WKSP
    part_id                         number,
    current_price_break_quantity_1  number,
    quantity_available              number,
    vendor_public_qty               number,
    code_lead_content               number,
    code_rohs_status                number,
    nflag_supplier_dir_ship_part    number,
    enterprise_source_code          number,
    vendor_quantity_on_order        number,
    code_qty_avail_type             number,
    --From IN_PART_HEADER_DF
    so_ship_deficit                 number,
    so_bo_deficit                   number
  );

  type search_data_header_table is table of t_in_search_data_struc;

  type in_foreign_cost_wksp is record (
    current_cost              number,
    duty_cost                 number,
    duty_multiplier           number,
    exchange_rate_multiplier  number,
    foreign_resale_multiplier number,
    local_market_multiplier   number,
    foreign_price             number,
    transport_cost            number,
    transport_multiplier      number,
    us_price                  number
  );
  type t_cost_struc is record (
      cost_1 number,
      cost_break_quantity_1 number
  );
  type cost_array is table of t_cost_struc;

  type t_current_pricing_struc is record (
      current_multiplier_1 number,
      current_price_1 number,
      current_price_break_quantity_1 number,
      current_round_off_rule_1 char
  );
  type pricing_table is table of t_current_pricing_struc;

  type t_break_struc is record (
      break_1 number
  );
  type break_table is table of t_break_struc;

  type t_vendor_id_list is record (
      vendor_id number
  );
  type vendor_id_table is table of t_vendor_id_list;

  type t_in_vendor_id_list_wksp is record (
      break_1 number,
      error_text varchar2(132),
      flag_sample char,
      nflag_ignore_digireel number,
      nflag_lead_rohs_comp_req number,
      quantity_available number,
      vendor_ids vendor_id_table
  );

  type t_in_part_header_df is record (
      hdr in_part_header_rec%rowtype,

      break_struc break_table,
      pricing_struc pricing_table
  );

  type t_part_table is table of in_part_header_rec%rowtype;

  type t_in_compute_pricing_wksp is record (
      pricing_list pricing_table
  );

  type t_pricing_wksp is record (
      part_id number,
      date_sales_enabled date,
      date_last_buy_chance date,
      quantity_available number,
      vendor_public_qty number,
      current_price_break_quantity_1 number,
      code_lead_content number,
      code_rohs_status number,
      flag_obsolete char,
      flag_close_out char,
      flag_discontinued char,
      nflag_pending_conversion number,
      nflag_dkc_discontinued number,
      nflag_va_discontinued number,
      nflag_region_adjusted_us_price number,
      nflag_bo_not_allowed number,
      nflag_supplier_dir_ship_part number,
      country_of_origin_lov char(2)
  );

  type t_in_misc_pricing_wksp is record (
      date_field date,
      duty_multiplier number,
      transport_multiplier number,
      exchange_rate_multiplier number,
      foreign_resale_multiplier number,
      local_market_multiplier number,
      company_type number,
      country_currency_code number,
      currency_divisor number,
      customer_id number,
      salesorder_id number,
      special_packaging_code number,
      code_geo_region number,
      nflag_override_special_pricing number,
      nflag_special_pricing number,
      nflag_regional_pricing_applied number,
      pricing_country_lov char(2)
  );

  type gs_lov_currency_lookup_wksp is record (
    country_currency_code number,
    currency_code_iso_4217 char(3),
    currency_poss_plus_symbol char(12),
    country_description char(20),
    currency_poss char(12),
    currency_divisor number,
    status_text char(40)
  );

  type number_table is table of number;

  type t_wb_part_pricing_rec is record (
    part_id number,
    country_currency_code number,
    code_geo_region number,
    price_break_quantity number_table,
    unit_price number_table
  );

  type wb_part_pricing_list is table of t_wb_part_pricing_rec;

  type t_wb_part_pricing_upd_rec is record (
    update_type number,
    status number,
    row_id rowid,
    wb_rec wb_part_price_rec%rowtype
  );

  type wb_part_pricing_upd_list is table of t_wb_part_pricing_upd_rec;

  type wb_price_update_rec is record (
    failure_count number,
    ul wb_part_pricing_upd_list
  );

  type t_part_update_rec is record (
    parts_read number,
    parts_updated number,
    parts_inserted number,
    parts_skipped number,
    failure_count number,
    --generic values for debug info if needed
    generic_number number,
    generic_string varchar2(64),
    --specific part info for debugging when run for single part
    part_id number,
    country_currency_code number,
    region number
  );

  type t_diff_rec is record (
    record_type number,
    part_id number,
    field number,
    wb_value number,
    pr_value number
  );

  type diff_table is table of t_diff_rec;

  type part_update_rec_table is table of t_part_update_rec;

  type t_region_multiplier_rec is record (
    country_currency_code number,
    code_geo_region number,
    exchange_rate_multiplier number,
    transport_multiplier number
  );

  type region_multiplier_table is table of t_region_multiplier_rec index by binary_integer;

  type t_foreign_rate_rec is record (
    country_currency_code number,
    multiplier_table region_multiplier_table
  );

  type foreign_rate_table is table of t_foreign_rate_rec index by binary_integer;

  type t_duty_rate_table is table of number index by varchar2(64);

  type t_refcursor is ref cursor;

  procedure update_pricing_update_list(pricing_list in wb_part_pricing_list,
                                       wb_update_rec in out wb_price_update_rec,
                                       status in out number);

  procedure update_price_data(wb_update_rec in out wb_price_update_rec,
                              status in out number);

  procedure fill_foreign_rate_table(p_start_date in varchar2,
                                    p_currency in number default -1,
                                    p_region in number default -1);

  procedure fill_duty_rate_table(p_display_key in varchar2 default null);

  procedure wb_part_pricing_upd(part in number,
                                currency in number,
                                region in number);

  function in_wb_part_pricing_upd(part in number,
                                  currency in number,
                                  region in number) return part_update_rec_table pipelined;

  function get_price_data(part_header_df in out t_in_part_header_df,
                          pricing_list in out wb_part_pricing_list,
                          p_currency in number,
                          p_region in number,
                          p_currency_divisor in number) return number;

  function gs_is_pricing_call_digikey_ss(part_header in t_in_part_header_df,
                                         combined_quantities_wksp in out t_in_search_data_struc,
                                         bCallDigikey in out number) return number;

  function gs_is_no_stock_part_ss(current_date in date,
                                  part_header in t_in_part_header_df) return boolean;

  function in_compute_special_price_ss(part_header in t_in_part_header_df,
                                       pricing_wksp in out t_in_compute_pricing_wksp,
                                       misc_pricing_wksp in out t_in_misc_pricing_wksp,
                                       special_pricing_rec in in_special_pricing_rec%rowtype) return number;

  procedure CalculateDKUnitPrice(part_header in t_in_part_header_df,
                                 temp_qty in number,
                                 dk_unit_price in out number);

  procedure CalculateSpecialMultipliers(part_header in t_in_part_header_df,
                                        pricing_wksp in out t_in_compute_pricing_wksp,
                                        misc_pricing_wksp in t_in_misc_pricing_wksp,
                                        exchange_rate in number);

  procedure CalculateSpecialPricing(tier in number,
                                    special_pricing_rec in in_special_pricing_rec%rowtype,
                                    pricing_wksp in out t_in_compute_pricing_wksp);

  procedure ComputeRemainingTiers(adjustedIndex in number,
                                  tier in number,
                                  special_pricing_rec in in_special_pricing_rec%rowtype,
                                  pricing_wksp in out t_in_compute_pricing_wksp);

  procedure GetInitialTierPrice(special_pricing_rec in_special_pricing_rec%rowtype,
                                qty in number,
                                tier in number,
                                price in out number);


  procedure GetInitialBreakTier(special_pricing_rec in in_special_pricing_rec%rowtype,
                                temp_qty in number,
                                tier in out number);

  function in_compute_pricing_sp(p_part_id in number,
                                 p_country_currency_code in number,
                                 p_code_geo_region in number,
                                 p_company_type in number,
                                 p_foreign_rate_date in varchar) return in_compute_pricing_return_tbl pipelined;

  function in_compute_pricing_ss(part_header in t_in_part_header_df,
                                 pricing_wksp in out t_in_compute_pricing_wksp,
                                 misc_pricing_wksp in out t_in_misc_pricing_wksp) return number;

  function compute_pricing(part_header in t_in_part_header_df,
                           pricing_wksp in out t_in_compute_pricing_wksp,
                           misc_pricing_wksp in out t_in_misc_pricing_wksp,
                           mapped_region in number) return number;

  function in_compute_foreign_price_ss(part_header in t_in_part_header_df,
                                       pricing_wksp in out t_in_compute_pricing_wksp,
                                       misc_pricing_wksp in out t_in_misc_pricing_wksp) return number;

  function calculate_foreign_price(part_header t_in_part_header_df,
                                   misc_pricing_wksp t_in_misc_pricing_wksp,
                                   pricing_wksp in out t_in_compute_pricing_wksp) return number;

  procedure copy_pricing_list(dst in out pricing_table, src in pricing_table);

  procedure IN_SPECIAL_PRICING_REC_DEFAULT(pricing_rec in out in_special_pricing_rec%rowtype);

  function GetMultipliers(part_header in t_in_part_header_df,
                          pricing_wksp in out t_in_misc_pricing_wksp,
                          mapped_region in number) return number;

  procedure IN_COMPUTE_PRICING_RETURN_DFLT(rec in out t_in_compute_pricing_return);

  procedure IN_COMPUTE_PRICING_WKSP_DFLT(wksp in out t_in_compute_pricing_wksp);

  procedure IN_MISC_PRICING_WKSP_DFLT(wksp in out t_in_misc_pricing_wksp);

  function SelectGreaterPricing(special_pricing_wksp in t_in_compute_pricing_wksp,
                                dkc_pricing_wksp in t_in_compute_pricing_wksp, 
                                new_pricing_wksp in out t_in_compute_pricing_wksp) return number;

  function CalcCurrentMultipliers(pricing_wksp in out t_in_compute_pricing_wksp,
                                  part_header in t_in_part_header_df) return number;

  function CalcUnitPrice(price in number, quantity in number) return number;

  function FindDkcCatalogTier(qty in number,
                              part_header in t_in_part_header_df) return number;

  function DeterminePricingTypes(misc_pricing_wksp in out t_in_misc_pricing_wksp,
                                 part_header in t_in_part_header_df,
                                 nflag_use_special_price in out number, 
                                 nflag_use_foreign_mult in out number,
                                 mapped_region in number) return number;

  function so_order_ship_adrs_load_ss(p_customer_id in number,
                                      order_ship_rec in out so_order_ship_adrs_rec%rowtype) return number;

  procedure SO_ORDER_SHIP_ADRS_REC_DEFAULT(order_ship_rec in out so_order_ship_adrs_rec%rowtype);

  function so_order_ship_adrs_load_dte_ss(p_customer_id in number,
                                          order_ship_rec in out so_order_ship_adrs_rec%rowtype,
                                          date_modified in out date) return number;

  procedure GS_COUNTRY_REGION_REC_DEFAULT(country_region_rec in out gs_country_region_rec%rowtype);

  function is_dk_entity_company_type(code in number) return boolean;

  function is_dkc_company_type(code in number) return boolean;

  function gs_country_region_read_ss(country_region_rec in out gs_country_region_rec%rowtype) return number;

  function gs_csp_find_region(company_type in number,
                              country_lov in char,
                              region in out number) return number;

  function is_company_region_pricing(company_type in number) return boolean;

  function GetRegion(in_misc_pricing_wksp in out t_in_misc_pricing_wksp,
                     region in out number) return number;


  procedure SAMPLE_PROFILE_REC_DEFAULT(profile_rec in out so_sample_program_profile_rec%rowtype, 
                                       default_value in char default ' ');

  function gs_sample_profile_read_esc(profile_rec in out so_sample_program_profile_rec%rowtype) return number;

  function gs_sample_profile_read_spc(profile_rec in out so_sample_program_profile_rec%rowtype) return number;

  function gs_sample_profile_read_ss(profile_rec in out so_sample_program_profile_rec%rowtype) return number;

  function gs_is_sample_order_ss(enterprise_source_code in number,
                                 isSample in out number) return number;

  function gs_adj_qty_ss(code_compliant_type in number,
                         qty_avail_1 in number,
                         sample_rsv_1 in number,
                         qty_avail_2 in number,
                         sample_rsv_2 in number,
                         enterprise_source_code in number,
                         adj_qty_avail in out number) return number;

  function get_link(sqlcode in out number,
                    part_id in number,
                    parent in number,
                    link_type in number) return number;

  function addPartsToList(requested_part in in_part_header_rec%rowtype,
                          parts_list in out gs_parts_available_list,
                          enterprise_source_code in number) return number;
                          
  function gs_is_sample_model_b_ss(enterprise_source_code in number) return boolean;

  function gs_get_parts_available_ss(requested_part in in_part_header_rec%rowtype,
                                     parts_list in out gs_parts_available_list,
                                     enterprise_source_code in number) return number;

  procedure IN_SEARCH_DATA_STRUC_DFLT(in_search_data in out t_in_search_data_struc,
                                      default_value number default 0);

  function get_additional_quantities(part_header in in_part_header_rec%rowtype, 
                                     combined_quantities_wksp in out t_in_search_data_struc,
                                     parts_list in out gs_parts_available_list,
                                     bGetTrQty in number,
                                     bGetRegularCtQty in number) return number;

  function get_quantity_available(part_header in in_part_header_rec%rowtype, 
                                  combined_quantities_wksp in out t_in_search_data_struc,
                                  parts_list in out gs_parts_available_list,
                                  unique_parts_list in out gs_parts_available_list) return number;

  function in_calc_combined_quantities_ss(part_header in in_part_header_rec%rowtype,
                                          combined_quantities_wksp in out t_in_search_data_struc,
                                          parts_list in out gs_parts_available_list) return number;
                                          
  function in_calc_combined_quantities(p_part_id in number) return number;

  function IsLeadFree(code_lead_content in number) return boolean;

  function IsRohsCompliant(code_rohs_status in number) return boolean;

  function in_calc_combined_lead_rohs_ss(part_header in in_part_header_rec%rowtype,
                                         combined_quantities_wksp in out t_in_search_data_struc,
                                         parts_list in out gs_parts_available_list) return number;

  function in_calc_search_data_header_ss(part_header in in_part_header_rec%rowtype,
                                         combined_quantities_wksp in out t_in_search_data_struc) return number;
                                         
  function in_calc_search_data_header(p_part_id in number,
                                      p_master_part_id in number,
                                      p_maximum_order_quantity in number,
                                      p_current_price_break_qty_1 in number,
                                      p_drop_ship_type in char,
                                      p_code_additional_fee in number,
                                      p_flag_non_stock in char,
                                      p_part_type in number,
                                      p_nflag_va_discontinued in number,
                                      p_code_lead_content in number,
                                      p_code_rohs_status in number,
                                      p_quantity_available in number,
                                      p_vendor_public_qty in number,
                                      p_vendor_quantity_on_order in number,
                                      p_so_ship_deficit in number,
                                      p_so_bo_deficit in number,
                                      p_so_sample_reserved in number,
                                      p_nflag_consigned in number
                                     ) return search_data_header_table pipelined;
                                     
  procedure in_foreign_pricing_back_out_ss(status out number, wksp in out in_foreign_cost_wksp);

  procedure IN_FOREIGN_COST_WKSP_DEFAULT(foreign_cost_wksp in out in_foreign_cost_wksp);

  function in_foreign_pricing_back_out(country_currency_code in number,
                                       break_price in number, 
                                       duty_multiplier in number,
                                       exchange_rate_multiplier in number,
                                       transport_multiplier in number,
                                       local_market_multiplier in number) return number;

  procedure refactor_result(part_header in_part_header_rec%rowtype, part_cost_df in cost_array,
                            vendor_effective_minimum in out number);

  procedure calc_raw_dollar_qty(amount in number, cost_in in number, raw_dollar_qty out number);

  procedure Choose_Break_Qty(part_cost_df in cost_array, amount in number, min_dollar_qty out number);

  procedure in_calc_vendor_eff_min_ss(status out number,
                                      part_header in in_part_header_rec%rowtype,
                                      part_cost_df in cost_array,
                                      flag_convert_to_dkc in varchar2,
                                      vendor_dollar_qty in out number,
                                      vendor_effective_minimum in out number);

  procedure cost_rec_to_cost_df(cost_rec in in_part_cost_rec%rowtype, cost_df in out cost_array);

  function in_calc_vendor_eff_min(passed_part_id in number, flag_convert_to_dkc in varchar2) return number;

  function isspace(c_in in char) return number;
  
  function ispunct(c_in in char) return number;
  
  function in_part_remove_punct_ss(part_number in varchar2, formatted_part_number out varchar2) return number;

  procedure IN_PART_HEADER_DF_DEFAULT(df in out t_in_part_header_df);

  procedure IN_VENDOR_ID_LIST_WKSP_DEFAULT(wksp in out t_in_vendor_id_list_wksp);
  
  procedure part_df_to_part_header(df_rec in t_in_part_header_df, header_rec in out in_part_header_rec%rowtype);

  procedure fill_header_df_tables(df_rec in out t_in_part_header_df);
  
  procedure part_header_to_part_df(header_rec in in_part_header_rec%rowtype, df_rec in out t_in_part_header_df);
  
  function isSpecial(passed_header_df in t_in_part_header_df, flag_sample in char) return number;     
                                    
  function IsElement(vendor_id in number, vendor_wksp in t_in_vendor_id_list_wksp) return number;
  
  function IsLinked(a in in_part_header_rec%rowtype, b in in_part_header_rec%rowtype, linked out number) return number;
  
  function DetermineClosestMatch(break_1 in number,
                                 flag_sample in char,
                                 nflag_lead_rohs_comp_req in char,
                                 filtered_match_header_df in out t_in_part_header_df,
                                 temp_mfg_header_df in out t_in_part_header_df,
                                 filtered_match_part_id in out number,
                                 filtered_match_part_dbkey in out number) return number;

  function IsCompliant(passed_header_df in t_in_part_header_df,
                       nflag_lead_rohs_comp_req in number,
                       isCompliant out number) return number;
                       
  procedure PerformSpecialCheck(nflag_suppress_manuf_search in number,
                                nflag_suppress_special_check in number,
                                temp_mfg_header in in_part_header_rec%rowtype,
                                temp_report_header in_part_header_rec%rowtype,
                                status out number);
                                
  function FilterByConsigned(filtered_match_header_df in out t_in_part_header_df,
                             temp_mfg_header_df in t_in_part_header_df,
                             filtered_match_part_id out number,
                             filtered_match_part_dbkey out number) return number;

  function FilterByValueAdd(filtered_match_header_df in out t_in_part_header_df,
                            temp_mfg_header_df in t_in_part_header_df,
                            filtered_match_part_id out number,
                            filtered_match_part_dbkey out number) return number;

  function FilterByCompliancy(filtered_match_header_df in out t_in_part_header_df,
                              temp_mfg_header_df in t_in_part_header_df,
                              filtered_match_part_id out number,
                              filtered_match_part_dbkey out number) return number;

  function FilterByPriceBreaks(break_1 in number,
                               filtered_match_header_df in out t_in_part_header_df,
                               temp_mfg_header_df in t_in_part_header_df,
                               filtered_match_part_id out number,
                               filtered_match_part_dbkey out number) return number;

  function PerformFilterScan(part_id in out number,
                             part_number in varchar2,
                             vendor_id_list_wksp in out t_in_vendor_id_list_wksp,
                             part_dbkey in out number,
                             part_header in out in_part_header_rec%rowtype) return number;
                             
  function PassesInvFlagChecks(passed_header_df in t_in_part_header_df,
                              in_vendor_id_list_wksp out t_in_vendor_id_list_wksp,
                              current_matched_part_id in out number) return number;
                              
  procedure PerformFiltering(in_vendor_id_list_wksp in out t_in_vendor_id_list_wksp,
                             current_matched_part_id in out number,
                             current_matched_header_df in out t_in_part_header_df,
                             current_matched_part_dbkey in out number,
                             potential_part_id in out number,
                             potential_header_df in out t_in_part_header_df,
                             potential_part_dbkey in number,
                             status out number);
                             
  function PerformIndustryFilterScan(part_id in out number,
                                     part_number in varchar2,
                                     vendor_id_list_wksp in out t_in_vendor_id_list_wksp,
                                     part_dbkey out number,
                                     part_header_rec out in_part_header_rec%rowtype) return number;

  function in_part_lookup_ss(
--                              part_dbkey out number,
--                              part_header_rec out in_part_header_rec%rowtype,
                              p_part_id in number,
                              p_part_number in varchar,
                              nflag_suppress_manuf_search in number,
                              nflag_suppress_special_check in number,
                              nflag_suppress_xtra_search in number
--                              in_vendor_id_list_wksp in out t_in_vendor_id_list_wksp
                              ) return t_part_table pipelined;

END IN_PACKAGE;
/
