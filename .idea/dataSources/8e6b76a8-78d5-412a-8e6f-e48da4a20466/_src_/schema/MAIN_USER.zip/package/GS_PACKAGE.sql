CREATE PACKAGE           GS_PACKAGE AS

  type t_refcursor is ref cursor;

  type t_derived_part is record (
    master_part_id number,
    part_id number,
    nflag_consigned number,
    quantity_available number,
    so_sample_reserved number,
    part_type number,
    report_part_number varchar2(48)
  );
  type t_derived_table is table of t_derived_part;
  type t_part_table is table of in_part_header_rec%rowtype;

  type t_gs_reserve_item_wksp is record (
    reserve_rec gs_reserve_rec%rowtype,
    dbkey number
  );

  type t_reservation_list is table of t_gs_reserve_item_wksp;

  procedure GS_RESERVE_ITEM_WKSP_DEFAULT(rsv_wksp in out t_gs_reserve_item_wksp);
  procedure GetPartHeader(status out number, passed_part_id in number, header_rec out in_part_header_rec%rowtype);
  procedure gs_is_ndr_record_ss(status out number, passed_part_id in number, nflag_ndr out number);
  procedure FindPartByType(sql_code out number, passed_part_id in number, passed_part_type in number,
                           bMatch out number, returned_header_rec out in_part_header_rec%rowtype);
  procedure GetLeadLinkPartId(status out number, passed_part_id in number, record_type in number,
                              returned_part_id out number);
  procedure select_part_link_by_comp_id(sql_code out number, link_rec in out in_part_link_rec%rowtype);
  procedure select_part_link_by_par_id(sql_code out number, link_rec in out in_part_link_rec%rowtype);
  procedure gs_get_derived_linked_part_ss(status out number, passed_header_rec in in_part_header_rec%rowtype,
                                          fetched_header_rec out in_part_header_rec%rowtype,
                                          nflag_master in number, code_derived_group in number,
                                          part_type in number);
  procedure GetDerivedList(status out number, master_part_id in number, curs in out t_refcursor);
  procedure GetLeadLinkRecord(status out number, part_id in number, header_rec out in_part_header_rec%rowtype);
  procedure copy_header_to_derived(master_id in number, part_header in in_part_header_rec%rowtype, derived_rec out t_derived_part);
  function gs_get_derived_linked_list_ss(passed_part_id in number,
                                         code_derived_group in number, blinkedonly in number,
                                         part_type in number) return t_derived_table pipelined;
  procedure gs_qw_mult_div_ss(a in number, b in number, c in number, result out number);
  function gs_country_region_read_ss(region_rec IN out gs_country_region_rec%rowtype) RETURN NUMBER;
  function gs_csp_find_region(company_type in number,
                              country_lov IN VARCHAR2,
                              region out number) return number;
  function region_price_cust_id(p_customer_id IN NUMBER,
                                p_country_currency_code IN NUMBER,
                                p_break_price in number,
                                p_duty_multiplier IN NUMBER,
                                p_transport_multiplier in number,
                                p_local_market_multiplier IN NUMBER,
                                p_exchange_rate_multiplier IN NUMBER,
                                p_foreign_resale_multiplier in number,
                                p_quantity_shipped in number,
                                p_break_quantity IN NUMBER) RETURN NUMBER;

  function region_price_co_type(p_company_type IN NUMBER,
                                p_adrs_country_lov in cs_customer_rec.adrs_country_lov%type,
                                p_country_currency_code IN NUMBER,
                                p_break_price in number,
                                p_duty_multiplier IN NUMBER,
                                p_transport_multiplier in number,
                                p_local_market_multiplier IN NUMBER,
                                p_exchange_rate_multiplier IN NUMBER,
                                p_foreign_resale_multiplier in number,
                                p_quantity_shipped IN NUMBER,
                                p_break_quantity in number) return number;

  function region_price(p_region in number,
                        p_country_currency_code in number,
                        p_break_price in number,
                        p_duty_multiplier in number,
                        p_transport_multiplier in number,
                        p_local_market_multiplier in number,
                        p_exchange_rate_multiplier in number,
                        p_foreign_resale_multiplier in number,
                        p_quantity_shipped in number,
                        P_BREAK_QUANTITY in number) return number;

  function gs_has_counter_core_cons_ss(p_part_id in number, nflag_consigned in number) return t_part_table pipelined;

  function gs_decrypt_buffer_er(buffer in varchar2, buffer_size in number) return varchar2;

  function get_exch_multplrs_er(ccc number, region number, exch_date timestamp) return number;

  function round_result(result1 number,ccc number) return number;

  function gs_currency_converter_er(original_ccc number, original_value number, new_ccc number,exch_rate_date timestamp) return number;

end gs_package;
/
