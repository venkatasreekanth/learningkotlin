CREATE package un_tools_module as

FUNCTION get_next_user_id (employee_id in UN_USER_HEADER_REC.EMPLOYEE_ID%TYPE)
                RETURN CHAR;

FUNCTION increment_char (in_char in char)
				RETURN CHAR;

end un_tools_module;
/
