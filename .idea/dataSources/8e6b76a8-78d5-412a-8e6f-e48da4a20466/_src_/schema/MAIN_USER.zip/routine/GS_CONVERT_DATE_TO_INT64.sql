CREATE function gs_convert_date_to_int64(this_date in timestamp)
   return NUMBER
   DETERMINISTIC
is
   epoch timestamp;
   m_diff interval day (7) to second (8);
   m_days int;
   m_hours int;
   m_minutes int;
   m_seconds number;

   begin
   -- Get Julian for input date
      epoch := to_timestamp('1858-11-17 00:00:00.000', 'YYYY-MM-DD HH24:MI:SS.FF3');
      m_diff := this_date - epoch;
      m_days := extract(day from m_diff);
      m_hours := extract(hour from m_diff);
      m_minutes := extract(minute from m_diff);
      m_seconds := extract(second from m_diff);
      return ((m_days*86400) + (m_hours*3600) + (m_minutes*60) + m_seconds)*10000000;
   end;
/
