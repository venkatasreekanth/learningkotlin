CREATE function gs_convert_char_to_int(in_chr in char)
   return number 
   DETERMINISTIC
   is
   my_int number(3,0);
   begin
   -- Check the value of 
      my_int := ASCII(in_chr);
      if my_int>127 then
         my_int := my_int-256;
      end if;
      return my_int;
   end;
/
