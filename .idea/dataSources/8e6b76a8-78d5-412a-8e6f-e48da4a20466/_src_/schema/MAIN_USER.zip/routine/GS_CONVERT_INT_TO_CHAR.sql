CREATE function gs_convert_int_to_char(in_int in number)
   return char
   DETERMINISTIC   
   is
   my_int number(3,0);
   begin
   -- Check the value of 
      if in_int<0 then
         my_int := 256+in_int;
      else
         my_int := in_int;
      end if;
      return chr(my_int);
   end;
/
