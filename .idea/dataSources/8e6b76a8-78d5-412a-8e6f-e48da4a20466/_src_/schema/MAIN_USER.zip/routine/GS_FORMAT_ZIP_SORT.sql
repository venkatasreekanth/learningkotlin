CREATE FUNCTION GS_FORMAT_ZIP_SORT
(
  ADRS_ZIP_CODE IN VARCHAR2,
  ADRS_COUNTRY_LOV IN VARCHAR2
) RETURN VARCHAR2 
  DETERMINISTIC
  IS
  ADRS_ZIP_SORT VARCHAR2(10);

flag_domestic_adrs char;
local_adrs_country_lov char(2);
sql_stmt VARCHAR2(200);

BEGIN

  local_adrs_country_lov := ADRS_COUNTRY_LOV;

  sql_stmt := 'SELECT TRIM(SUBSTR(NOTE, 33, 1)) FROM DK_LOV_DETAIL_REC where TABLE_NUMBER = 138 AND LOV_DISPLAY_KEY = :adrs_country_lov';
  EXECUTE IMMEDIATE sql_stmt INTO flag_domestic_adrs USING local_adrs_country_lov;

  if (flag_domestic_adrs <> 'F') then
      if (ADRS_COUNTRY_LOV = '05') then -- ADDRESS_COUNTRY$_CANADA
        ADRS_ZIP_SORT := SUBSTR(ADRS_ZIP_CODE, 0, 6) || '    '; -- ZIP_CODE_CANADA_LENGTH
      else
        ADRS_ZIP_SORT := SUBSTR(ADRS_ZIP_CODE, 0, 5) || '     '; -- ZIP_CODE_US_LENGTH
      end if;
  else
    ADRS_ZIP_SORT := ADRS_ZIP_CODE;
  end if;
  
  RETURN ADRS_ZIP_SORT;
  
  EXCEPTION
    WHEN OTHERS THEN
    ADRS_ZIP_SORT := SUBSTR(ADRS_ZIP_CODE, 0, 5); -- ZIP_CODE_US_LENGTH

  RETURN ADRS_ZIP_SORT;
  
END GS_FORMAT_ZIP_SORT;
/
