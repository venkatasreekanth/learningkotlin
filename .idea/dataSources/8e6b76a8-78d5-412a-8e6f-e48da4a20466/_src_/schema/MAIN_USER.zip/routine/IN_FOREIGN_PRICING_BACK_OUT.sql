CREATE FUNCTION IN_FOREIGN_PRICING_BACK_OUT
(
  country_currency_code IN INTEGER,
  break_price IN NUMBER,
  duty_multiplier IN NUMBER,
  exchange_rate_multiplier IN NUMBER,
  transport_multiplier IN NUMBER,
  local_market_multiplier IN NUMBER
) RETURN NUMBER 
  DETERMINISTIC
  IS
  us_price NUMBER;

CURRENCY_TYPE$_US CONSTANT INTEGER := 1;

BEGIN

  if ((country_currency_code = CURRENCY_TYPE$_US) or (exchange_rate_multiplier = 0)) then -- If the exchange_rate_multiplier is zero, the price already is in U.S.A. currency.
  
    RETURN break_price;
  
  end if;
  
  RETURN CALCULATE_US_PRICE(break_price, duty_multiplier, transport_multiplier, exchange_rate_multiplier);

END IN_FOREIGN_PRICING_BACK_OUT;
/
