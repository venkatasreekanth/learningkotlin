CREATE FUNCTION           so_detail_index_lookup_ss(p_salesorder_id in number, p_block_id in number, p_block_sequence in number) return number as idx number(10,0);
  srec so_order_detail_access_rec%rowtype;
  blockid number := 0;
  begin
     idx := 0;
     while (true)
     loop
      select * into srec from so_order_detail_access_rec where salesorder_id = p_salesorder_id and block_id = blockid;
      if sql%notfound then
         goto idx_found;
      end if;
      if srec.detail_access_glue_0 != -1 then
         if srec.detail_access_glue_0 = p_block_id then
            goto idx_found;
         else
            idx := idx + srec.detail_count_0;
         end if;
      end if;
      if srec.detail_access_glue_1 != -1 then
         if srec.detail_access_glue_1 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_1;
         end if;
      end if;
      if srec.detail_access_glue_2 != -1 then
         if srec.detail_access_glue_2 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_2;
         end if;
      end if;
      if srec.detail_access_glue_3 != -1 then
         if srec.detail_access_glue_3 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_3;
         end if;
      end if;
      if srec.detail_access_glue_4 != -1 then
         if srec.detail_access_glue_4 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_4;
         end if;
      end if;
      if srec.detail_access_glue_5 != -1 then
         if srec.detail_access_glue_5 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_5;
         end if;
      end if;
      if srec.detail_access_glue_6 != -1 then
         if srec.detail_access_glue_6 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_6;
         end if;
      end if;
      if srec.detail_access_glue_7 != -1 then
         if srec.detail_access_glue_7 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_7;
         end if;
      end if;
      if srec.detail_access_glue_8 != -1 then
         if srec.detail_access_glue_8 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_8;
         end if;
      end if;
      if srec.detail_access_glue_9 != -1 then
         if srec.detail_access_glue_9 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_9;
         end if;
      end if;
      if srec.detail_access_glue_10 != -1 then
         if srec.detail_access_glue_10 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_10;
         end if;
      end if;
      if srec.detail_access_glue_11 != -1 then
         if srec.detail_access_glue_11 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_11;
         end if;
      end if;
      if srec.detail_access_glue_12 != -1 then
         if srec.detail_access_glue_12 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_12;
         end if;
      end if;
      if srec.detail_access_glue_13 != -1 then
         if srec.detail_access_glue_13 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_13;
         end if;
      end if;
      if srec.detail_access_glue_14 != -1 then
         if srec.detail_access_glue_14 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_14;
         end if;
      end if;
      if srec.detail_access_glue_15 != -1 then
         if srec.detail_access_glue_15 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_15;
         end if;
      end if;
      if srec.detail_access_glue_16 != -1 then
         if srec.detail_access_glue_16 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_16;
         end if;
      end if;
      if srec.detail_access_glue_17 != -1 then
         if srec.detail_access_glue_17 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_17;
         end if;
      end if;
      if srec.detail_access_glue_18 != -1 then
         if srec.detail_access_glue_18 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_18;
         end if;
      end if;
      if srec.detail_access_glue_19 != -1 then
         if srec.detail_access_glue_19 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_19;
         end if;
      end if;
      if srec.detail_access_glue_20 != -1 then
         if srec.detail_access_glue_20 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_20;
         end if;
      end if;
      if srec.detail_access_glue_21 != -1 then
         if srec.detail_access_glue_21 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_21;
         end if;
      end if;
      if srec.detail_access_glue_22 != -1 then
         if srec.detail_access_glue_22 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_22;
         end if;
      end if;
      if srec.detail_access_glue_23 != -1 then
         if srec.detail_access_glue_23 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_23;
         end if;
      end if;
      if srec.detail_access_glue_24 != -1 then
         if srec.detail_access_glue_24 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_24;
         end if;
      end if;
      if srec.detail_access_glue_25 != -1 then
         if srec.detail_access_glue_25 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_25;
         end if;
      end if;
      if srec.detail_access_glue_26 != -1 then
         if srec.detail_access_glue_26 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_26;
         end if;
      end if;
      if srec.detail_access_glue_27 != -1 then
         if srec.detail_access_glue_27 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_27;
         end if;
      end if;
      if srec.detail_access_glue_28 != -1 then
         if srec.detail_access_glue_28 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_28;
         end if;
      end if;
      if srec.detail_access_glue_29 != -1 then
         if srec.detail_access_glue_29 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_29;
         end if;
      end if;
      if srec.detail_access_glue_30 != -1 then
         if srec.detail_access_glue_30 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_30;
         end if;
      end if;
      if srec.detail_access_glue_31 != -1 then
         if srec.detail_access_glue_31 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_31;
         end if;
      end if;
      if srec.detail_access_glue_32 != -1 then
         if srec.detail_access_glue_32 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_32;
         end if;
      end if;
      if srec.detail_access_glue_33 != -1 then
         if srec.detail_access_glue_33 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_33;
         end if;
      end if;
      if srec.detail_access_glue_34 != -1 then
         if srec.detail_access_glue_34 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_34;
         end if;
      end if;
      if srec.detail_access_glue_35 != -1 then
         if srec.detail_access_glue_35 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_35;
         end if;
      end if;
      if srec.detail_access_glue_36 != -1 then
         if srec.detail_access_glue_36 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_36;
         end if;
      end if;
      if srec.detail_access_glue_37 != -1 then
         if srec.detail_access_glue_37 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_37;
         end if;
      end if;
      if srec.detail_access_glue_38 != -1 then
         if srec.detail_access_glue_38 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_38;
         end if;
      end if;
      if srec.detail_access_glue_39 != -1 then
         if srec.detail_access_glue_39 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_39;
         end if;
      end if;
      if srec.detail_access_glue_40 != -1 then
         if srec.detail_access_glue_40 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_40;
         end if;
      end if;
      if srec.detail_access_glue_41 != -1 then
         if srec.detail_access_glue_41 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_41;
         end if;
      end if;
      if srec.detail_access_glue_42 != -1 then
         if srec.detail_access_glue_42 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_42;
         end if;
      end if;
      if srec.detail_access_glue_43 != -1 then
         if srec.detail_access_glue_43 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_43;
         end if;
      end if;
      if srec.detail_access_glue_44 != -1 then
         if srec.detail_access_glue_44 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_44;
         end if;
      end if;
      if srec.detail_access_glue_45 != -1 then
         if srec.detail_access_glue_45 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_45;
         end if;
      end if;
      if srec.detail_access_glue_46 != -1 then
         if srec.detail_access_glue_46 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_46;
         end if;
      end if;
      if srec.detail_access_glue_47 != -1 then
         if srec.detail_access_glue_47 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_47;
         end if;
      end if;
      if srec.detail_access_glue_48 != -1 then
         if srec.detail_access_glue_48 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_48;
         end if;
      end if;
      if srec.detail_access_glue_49 != -1 then
         if srec.detail_access_glue_49 = p_block_id then
            goto idx_found;
         else
            idx := idx +  srec.detail_count_49;
         end if;
      end if;
      blockid := blockid + 1;
   end loop;
<<idx_found>>
   idx := idx + p_block_sequence + 1;
   return idx;
   EXCEPTION
     when NO_DATA_FOUND then
       return 0;
end so_detail_index_lookup_ss;
/
