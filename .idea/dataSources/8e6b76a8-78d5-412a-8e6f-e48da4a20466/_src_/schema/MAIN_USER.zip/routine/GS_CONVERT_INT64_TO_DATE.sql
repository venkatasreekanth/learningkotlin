CREATE function gs_convert_int64_to_date (this_interval in number)
   return VARCHAR2 
   DETERMINISTIC   
 is
   epoch timestamp ;
   m_days int;
   m_seconds number;
   m_diff1 interval day (9) to second (0);
   m_diff2 interval day (5) to second(7);
   begin
   -- Get Julian for input date
      epoch := to_timestamp('1858-11-17 00:00:00.000', 'YYYY-MM-DD HH24:MI:SS.FF3');
      m_days    := this_interval /864000000000;
      m_seconds := this_interval - (m_days*864000000000);
      m_diff1 := numtodsinterval(m_days, 'DAY');
      m_seconds := m_seconds/10000000;
      m_diff2 := numtodsinterval(m_seconds, 'SECOND');

     return TO_CHAR(epoch+m_diff1+m_diff2, 'DD-MON-YYYY HH.MI.SSXFF AM');
   end gs_convert_int64_to_date ;
/
