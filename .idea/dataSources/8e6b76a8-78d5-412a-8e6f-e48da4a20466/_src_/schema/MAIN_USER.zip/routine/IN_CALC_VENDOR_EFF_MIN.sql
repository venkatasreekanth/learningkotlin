CREATE FUNCTION IN_CALC_VENDOR_EFF_MIN
(
  part_id IN NUMBER,
  flag_convert_to_dkc IN VARCHAR2
) RETURN NUMBER IS
  vendor_effective_minimum integer;

COST_TABLE_SIZE constant integer := 12;

PLS_INTEGER_MAX constant integer := 2147483647;

bigger1 integer := 0;
bigger2 integer := 0;

Type COSTS_ARRAY IS VARRAY(12) OF integer;
Type COST_BREAK_QUANTITIES_ARRAY IS VARRAY(12) OF integer;

costs COSTS_ARRAY := COSTS_ARRAY(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
cost_break_quantities COST_BREAK_QUANTITIES_ARRAY := COST_BREAK_QUANTITIES_ARRAY(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

conversion_dkc_quantity integer := 0;
conversion_vendor_quantity integer := 0;
vendor_dollar_qty integer := 0;
vendor_minimum_line_amount integer := 0;
vendor_minimum_line_quantity integer := 0;
vendor_order_multiple integer := 0;
local_effective_minimum integer := 0;
loop_counter integer := 0;
raw_dollar_qty integer := 0;
record_type string(1) := ' ';
found integer := 0;
temp_calculated_value integer := 0;
refactored_dollar_amount integer := 0;
refactored_dollar_qty integer := 0;
sql_stmt VARCHAR2(600);

PROCEDURE Add_Order_Multiple(order_mult IN integer, eff_min IN OUT integer) IS
BEGIN

    -- Factor in the order increment variable, if applicable.  Eff_min is the output.

    if (order_mult > 1) then
    
        temp_calculated_value := MOD(eff_min, order_mult);
        
        if (temp_calculated_value <> 0) then
        
            eff_min := (eff_min - temp_calculated_value + order_mult);
                
        end if;
                    
    end if;

END;

PROCEDURE Calc_Raw_Dollar_Qty(passed_amount IN integer, passed_cost IN number, passed_raw_dollar_qty IN OUT integer) IS
BEGIN

    --  Calculate a quantity from the minimum amount and a cost.  The following calculation always rounds
    --  the result up.  First scale to 5 implied decimal
    --  places, then add an amount equal to 1 less than the divisor, then divide.  Raw_dollar_qty is the output.

    if (passed_cost > 0) then
    
        temp_calculated_value := FLOOR(((1000 * passed_amount) + (passed_cost - 1)) / passed_cost);
               
        if (temp_calculated_value <= PLS_INTEGER_MAX) then
        
                passed_raw_dollar_qty := temp_calculated_value;
                
        else
                
                passed_raw_dollar_qty := -1; -- A negative value guarantees this won't be used.
                
        end if;
    
    else
            
        passed_raw_dollar_qty := 1; -- Quantity should be 1 for 0-price table. 
            
    end if;

END;

PROCEDURE Refactor_Result (vendor_minimum_line_amount IN number,
                            vendor_minimum_line_quantity IN integer,
                            vendor_order_multiple IN integer,
                            cost_break_quantities IN COST_BREAK_QUANTITIES_ARRAY,
                            costs IN COSTS_ARRAY,
                            vendor_effective_minimum IN OUT integer) IS
BEGIN

  found := 0;
      
  FOR i IN 1..COST_TABLE_SIZE LOOP
  
    if ((cost_break_quantities(i) > 0) and (found = 0)) then
    
        -- If last defined row in table (full or not), use its cost to refactor.  Otherwise use the slot that the effective minimum falls in.
 
        if ((i = COST_TABLE_SIZE - 1) or
            ((vendor_effective_minimum >= cost_break_quantities(i)) and
            ((vendor_effective_minimum < cost_break_quantities(i + 1)) or
            (cost_break_quantities(i + 1) = 0)))) then
    
            refactored_dollar_amount := (vendor_effective_minimum * costs(i)) / 1000.0;
            
            if (refactored_dollar_amount < vendor_minimum_line_amount) then
            
                Calc_Raw_Dollar_Qty(vendor_minimum_line_amount, costs(i), refactored_dollar_qty);

                bigger1 := GREATEST(refactored_dollar_qty, vendor_minimum_line_quantity);
                bigger2 := GREATEST(cost_break_quantities(1), vendor_order_multiple);
                vendor_effective_minimum := GREATEST(bigger1, bigger2);

                Add_Order_Multiple(vendor_order_multiple, vendor_effective_minimum);
 
            else
            
                found := 1;
                    
            end if;
        
        end if;
              
    end if;
  
  END LOOP;

END;

BEGIN

  DBMS_OUTPUT.ENABLE (buffer_size => NULL);
  
  local_effective_minimum := 0;

  sql_stmt := 'SELECT conversion_dkc_quantity, conversion_vendor_quantity, vendor_minimum_line_amount, vendor_minimum_line_quantity, vendor_order_multiple FROM IN_PART_HEADER_REC where PART_ID = :part_id';
  EXECUTE IMMEDIATE sql_stmt INTO conversion_dkc_quantity, conversion_vendor_quantity, vendor_minimum_line_amount, vendor_minimum_line_quantity, vendor_order_multiple USING part_id;

  BEGIN
  
    sql_stmt := 'SELECT COST_1, COST_2, COST_3, COST_4, COST_5, COST_6, COST_7, COST_8, COST_9, COST_10, COST_11, COST_12, COST_BREAK_QUANTITY_1, COST_BREAK_QUANTITY_2, COST_BREAK_QUANTITY_3, COST_BREAK_QUANTITY_4, COST_BREAK_QUANTITY_5, COST_BREAK_QUANTITY_6, COST_BREAK_QUANTITY_7, COST_BREAK_QUANTITY_8, COST_BREAK_QUANTITY_9, COST_BREAK_QUANTITY_10, COST_BREAK_QUANTITY_11, COST_BREAK_QUANTITY_12 FROM IN_PART_COST_REC where PART_ID = :part_id and RECORD_TYPE = :record_type';
    EXECUTE IMMEDIATE sql_stmt INTO costs(1), costs(2), costs(3), costs(4), costs(5), costs(6), costs(7), costs(8), costs(9), costs(10), costs(11), costs(12), cost_break_quantities(1), cost_break_quantities(2), cost_break_quantities(3), cost_break_quantities(4), cost_break_quantities(5), cost_break_quantities(6), cost_break_quantities(7), cost_break_quantities(8), cost_break_quantities(9), cost_break_quantities(10), cost_break_quantities(11), cost_break_quantities(12) USING part_id, record_type;

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE ('No Data found for SELECT on IN_PART_COST_REC');
      
  END;

  if (vendor_minimum_line_amount > 0) then

      if (cost_break_quantities(1) > 0) then
      
          if ((cost_break_quantities(1) = 1) and (costs(1) = 0)) then
              vendor_dollar_qty := 1;
                  
          else
          
              found := 0;
      
              FOR i IN 1..COST_TABLE_SIZE LOOP
              
                if ((cost_break_quantities(i) > 0) and (found = 0)) then
                  
                  Calc_Raw_Dollar_Qty(vendor_minimum_line_amount, costs(i), raw_dollar_qty);
                  
                  if ((raw_dollar_qty >= 0) and (raw_dollar_qty < cost_break_quantities(i + 1))) then
                  
                    found := 1;
                            
                  end if;
                
                end if;
              
              END LOOP;
              
              vendor_dollar_qty := raw_dollar_qty;

          end if;
              
      end if;        

  end if;
  
  --  Choose as the minimum the largest of the caculated dollar quantity, defined vendor minimum, first break, and order multiple.

  bigger1 := GREATEST(vendor_dollar_qty, vendor_minimum_line_quantity);
  bigger2 := GREATEST(cost_break_quantities(1), vendor_order_multiple);
  local_effective_minimum := GREATEST(bigger1, bigger2);
  
  Add_Order_Multiple(vendor_order_multiple, local_effective_minimum);
    
  -- Adding the order multiple may have bumped us into the next price break, which means the vendor minimum dollar amount might not be satisfied.  The following call will refactor the result if necessary.

  Refactor_Result(vendor_minimum_line_amount, vendor_minimum_line_quantity, vendor_order_multiple, cost_break_quantities, costs, local_effective_minimum);
   
  -- Do conversion of quantities from Vendor units to DKC units, if applicable.

  if (((flag_convert_to_dkc = 'T') or (flag_convert_to_dkc = 't')) and (conversion_dkc_quantity <> conversion_vendor_quantity) and (conversion_vendor_quantity > 0)) then
  
          --  Vendor units are different than DKC units.  The conversion will be from Vendor units to DKC units, always rounded up.
          
          --local_effective_minimum := ((local_effective_minimum * conversion_dkc_quantity) + (conversion_vendor_quantity - 1)) / conversion_vendor_quantity;
          
          local_effective_minimum := (local_effective_minimum * conversion_dkc_quantity) / conversion_vendor_quantity;
                      
  end if;
  
  RETURN local_effective_minimum;
  
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE ('No Data found for SELECT');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE ('Unexpected error');

  RETURN -1;

END IN_CALC_VENDOR_EFF_MIN;
/
