CREATE FUNCTION GS_DECRYPT_BUFFER
(
  buffer IN VARCHAR2,
  buffer_size IN INTEGER
) RETURN VARCHAR2 DETERMINISTIC IS

shift integer := 0;
shift_counter integer := 0;
new_char PLS_INTEGER := 0;

tempChar char(1);
tempString string(1);
decrypted_buffer VARCHAR2(1000);

BEGIN
	
	for i in 1 .. buffer_size
	loop
			
		shift := i + 1;
		shift_counter := 1;
		
		new_char := ASCII(substr(buffer, i, 1));
		
		loop
				
			if (shift_counter <= shift) then
			
				if (new_char = 32) then
        
					new_char := 127;
          
				end if;
        
				if (new_char = 127) then
          tempChar := ' ';
        else
          BEGIN
            tempChar := CHR(new_char);
            
            EXCEPTION WHEN OTHERS THEN
              DBMS_Output.Put_Line('new_char: ' || new_char || ' tempChar: ' || tempChar);
              tempChar := ' ';
          END;
        end if;
        
				tempString := tempChar;
               
				new_char := new_char - 1;
				shift_counter := shift_counter + 1;

			else
  
				exit;  -- exit loop immediately
    
			end if;
  
		end loop;
    
    decrypted_buffer := CONCAT(decrypted_buffer, tempString);
	
	end loop;
	
  RETURN decrypted_buffer;
  
END GS_DECRYPT_BUFFER;
/
